package com.nft.ncity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NcityApplicationTests {

	@Test
	void contextLoads() {
	}

}
