package com.nft.ncity.domain.favorite.response;

public class FavoriteRegisterPostRes {
}
